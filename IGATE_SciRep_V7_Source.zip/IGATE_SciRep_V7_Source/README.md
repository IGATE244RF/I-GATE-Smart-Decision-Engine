# I-GATE Scientific Reports V7 — Final Reproducibility Package

Run from this directory with `python run_primary.py`. The source package contains the exact V7 implementation and the result tables generated for the submitted benchmark.

Primary benchmark: 3,000 synthetic records, seed 42, 70/15/15 train/validation/test split, Transformer 5 epochs, Actor–Critic 50 episodes.

Implemented: nonlinear state transition; temporal Transformer; Actor–Critic; central finite-difference Jacobian; Hamiltonian; finite-horizon discrete-time Pontryagin forward-backward solver; System-Dynamics-compatible solve_ivp simulation; random/fixed-rule/greedy/Pontryagin baselines; five-seed robustness; 5/8/10-state ablation; correlation/effective-rank analysis.

Primary results: validation 0.8578; held-out test 0.8644; mean synthetic utility change 0.03268; effective rank 5.75; six held-out actions observed. HJB is formulated but not numerically solved. All benchmark results are synthetic and are not industrial performance claims.
