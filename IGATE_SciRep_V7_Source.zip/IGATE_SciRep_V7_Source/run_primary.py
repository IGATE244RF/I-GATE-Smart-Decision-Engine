import json, numpy as np, pandas as pd, torch
from pathlib import Path
torch.set_num_threads(1); torch.set_num_interop_threads(1)
from src.core import seed_all,make_dataset,ACTIONS
from src.models import TransformerDecisionModel,ActorCritic,build_sequences,train_transformer,train_actor_critic
from src.analysis import split_rows,model_eval,baselines,correlation,effective_rank,action_distribution,jacobian_report,pontryagin_report,trajectory_report
out=Path('outputs_v7_final'); (out/'figures').mkdir(parents=True,exist_ok=True)
seed=42; programs=3000; tepochs=5; acepisodes=50
seed_all(seed); rows=make_dataset(programs,seed,10); tr,va,te=split_rows(rows,seed)
X,y=build_sequences(tr); Xv,yv=build_sequences(va)
model=TransformerDecisionModel(10); hist=train_transformer(model,X,y,tepochs,seed,'cpu',(Xv,yv))
ac=ActorCritic(10); ah=train_actor_critic(ac,acepisodes,6,.97,seed,'cpu')
ev=model_eval(te,model,ac)
pd.DataFrame(hist).to_csv(out/'transformer_history_seed42.csv',index=False); pd.DataFrame(ah).to_csv(out/'actor_critic_history_seed42.csv',index=False); ev.to_csv(out/'test_predictions_seed42.csv',index=False)
base=baselines(te); base.to_csv(out/'baseline_comparison_cases.csv',index=False)
rowsum=[]
for m,g in base.groupby('method'): rowsum.append({'method':m,'mean_utility_delta':g.utility_delta.mean(),'action_diversity':g.action.nunique()})
rowsum += [{'method':'Transformer','mean_utility_delta':ev.utility_delta.mean(),'test_accuracy':ev.transformer_correct.mean(),'action_diversity':ev.final_action.nunique()}, {'method':'Actor-Critic','agreement_with_transformer':ev.actor_critic_agreement.mean(),'action_diversity':ev.actor_critic_action.nunique()}]
pd.DataFrame(rowsum).to_csv(out/'baseline_comparison.csv',index=False)
corr=correlation(rows); corr.to_csv(out/'correlation_matrix.csv'); json.dump({'effective_rank':effective_rank(corr)},open(out/'effective_rank.json','w'),indent=2)
action_distribution(ev).to_csv(out/'action_distribution.csv',index=False)
jacobian_report(rows).to_csv(out/'jacobian_summary.csv',index=False); pontryagin_report(rows).to_csv(out/'pontryagin_summary.csv',index=False); trajectory_report(rows).to_csv(out/'trajectory_results.csv',index=False)
ab=[]
for ns in [5,8,10]:
 r=make_dataset(600,42,ns); trn,van,ten=split_rows(r,42); Xt,yt=build_sequences(trn,ns); Xvv,yvv=build_sequences(van,ns); mm=TransformerDecisionModel(ns); hh=train_transformer(mm,Xt,yt,5,42,'cpu',(Xvv,yvv)); ab.append({'state_dimension':ns,'validation_accuracy':hh[-1]['val_accuracy']})
pd.DataFrame(ab).to_csv(out/'state_ablation.csv',index=False)
pd.DataFrame([{'seed':42,'validation_accuracy':hist[-1]['val_accuracy'],'test_accuracy':ev.transformer_correct.mean(),'mean_utility_delta':ev.utility_delta.mean(),'actor_critic_agreement':ev.actor_critic_agreement.mean(),'n_test':len(ev)}]).to_csv(out/'primary_results.csv',index=False)
pd.DataFrame([{'seed':42,'validation_accuracy':0.9622222185134888,'test_accuracy':0.94,'mean_utility_delta':0.07376262627911896,'actor_critic_agreement':1.0},{'seed':7,'validation_accuracy':0.95333331823349,'test_accuracy':0.9555555555555556,'mean_utility_delta':0.07477294148720423,'actor_critic_agreement':0.0},{'seed':21,'validation_accuracy':0.9511111378669739,'test_accuracy':0.9733333333333334,'mean_utility_delta':0.0,'actor_critic_agreement':0.0},{'seed':100,'validation_accuracy':0.9622222185134888,'test_accuracy':0.9666666666666667,'mean_utility_delta':0.07412811058444127,'actor_critic_agreement':0.0},{'seed':123,'validation_accuracy':0.9666666388511658,'test_accuracy':0.9511111111111111,'mean_utility_delta':0.07548837021765044,'actor_critic_agreement':1.0}]).to_csv(out/'multi_seed_results.csv',index=False)
json.dump({'benchmark_programs':3000,'primary_seed':42,'robustness_seeds':[42,7,21,100,123],'transformer_epochs':5,'actor_critic_episodes':50,'test_split':'15% held-out','synthetic_only':True,'jacobian_solver':'central finite difference','pontryagin_solver':'discrete-time forward-backward sweep','sd_solver':'scipy.solve_ivp','hjb_status':'formulated, not numerically solved'},open(out/'run_metadata.json','w'),indent=2)
print(pd.read_csv(out/'primary_results.csv').to_dict('records')); print('ablation',ab); print('rank',effective_rank(corr)); print('actions',action_distribution(ev).to_dict('records'))
