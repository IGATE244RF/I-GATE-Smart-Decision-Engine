from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .core import ACTIONS, STATE_NAMES, utility, transition, row_to_state, decision_score
from .solvers import transition_jacobian, pontryagin_solver, sd_simulate
from .models import TransformerDecisionModel, ActorCritic, build_sequences, train_transformer, train_actor_critic, predict


def split_rows(rows,seed=42):
    rng=np.random.default_rng(seed); idx=rng.permutation(len(rows)); n=len(rows); a=int(.70*n); b=int(.85*n)
    return [rows[i] for i in idx[:a]],[rows[i] for i in idx[a:b]],[rows[i] for i in idx[b:]]

def baselines(rows):
    records=[]
    for r in rows:
        x=row_to_state(r,10); g=int(r['gate']); scores=decision_score(x,gate=g)
        # The fixed rule follows the dynamic gate logic, while greedy is immediate utility.
        if x[2]>.65: fixed=2 if x[8]<.55 else 3
        elif x[8]<.55: fixed=2
        elif x[5]<.45: fixed=1
        elif x[3]>.65: fixed=4
        elif x[0]>.65: fixed=5
        else: fixed=0
        greedy=int(np.argmax(scores)); rnd=np.random.default_rng(g*100000+int(r['program_id'][1:])).integers(len(ACTIONS))
        psol=pontryagin_solver(x,horizon=6,gate=g)
        pa=int(psol['actions'][0])
        for name,a in [('random',rnd),('fixed_rule',fixed),('greedy',greedy),('pontryagin',pa)]:
            records.append({'program_id':r['program_id'],'method':name,'action':ACTIONS[a],'utility_delta':utility(transition(x,a,g))-utility(x)})
    return pd.DataFrame(records)

def model_eval(rows,transformer,ac,device='cpu'):
    out=[]
    for r in rows:
        x=row_to_state(r,10); g=int(r['gate']); seq=[x]
        for k in range(5): seq.append(transition(seq[-1],0,gate=min(g+k,5)))
        target=int(np.argmax(decision_score(x,gate=g)))
        ta,tp,_=predict(transformer,np.asarray(seq,np.float32),device=device); aa,ap,val=predict(ac,np.asarray(seq,np.float32),actor=True,device=device)
        final=ta
        out.append({'program_id':r['program_id'],'target_action':ACTIONS[target],'transformer_action':ACTIONS[ta],'actor_critic_action':ACTIONS[aa],'final_action':ACTIONS[final],'transformer_confidence':tp.max(),'actor_critic_confidence':ap.max(),'transformer_correct':int(ta==target),'actor_critic_agreement':int(ta==aa),'utility_delta':utility(transition(x,final,g))-utility(x)})
    return pd.DataFrame(out)

def correlation(rows):
    df=pd.DataFrame([{k:v for k,v in r.items() if k not in ('program_id','gate')} for r in rows]); return df.corr()

def effective_rank(corr):
    eig=np.linalg.eigvalsh(corr.to_numpy()); eig=np.clip(eig,0,None); p=eig/eig.sum(); return float(np.exp(-(p[p>0]*np.log(p[p>0])).sum()))

def action_distribution(df,method_col='final_action'):
    return df[method_col].value_counts(normalize=True).reindex(ACTIONS,fill_value=0).rename_axis('action').reset_index(name='proportion')

def jacobian_report(rows,per_action=30):
    sample=rows[:per_action]; rec=[]
    for r in sample:
        x=row_to_state(r,10); g=int(r['gate'])
        for a,name in enumerate(ACTIONS):
            J=transition_jacobian(x,a,g); sv=np.linalg.svd(J,compute_uv=False)
            rec.append({'program_id':r['program_id'],'action':name,'fro_norm':float(np.linalg.norm(J)), 'spectral_norm':float(sv[0]), 'trace':float(np.trace(J)), 'determinant':float(np.linalg.det(J))})
    return pd.DataFrame(rec)

def pontryagin_report(rows,per_cases=50):
    rec=[]
    for r in rows[:per_cases]:
        x=row_to_state(r,10); sol=pontryagin_solver(x,horizon=6,gate=int(r['gate']))
        rec.append({'program_id':r['program_id'],'action_sequence':'|'.join(sol['action_names']),'terminal_utility_gain':sol['terminal_utility_gain'],'mean_hamiltonian':float(np.mean(sol['hamiltonians'])),'iterations':sol['iterations']})
    return pd.DataFrame(rec)

def trajectory_report(rows):
    r=rows[0]; x=row_to_state(r,10); g=int(r['gate']);
    sequences={'baseline':[0]*6,'pontryagin':pontryagin_solver(x,6,g)['actions'].tolist()}
    out=[]
    for name,acts in sequences.items():
        t,states=sd_simulate(x,acts,12,g)
        for ti,s in zip(t,states): out.append({'scenario':name,'time':ti,'maturity':s[5],'risk':s[2],'validation':s[8],'confidence':s[9],'schedule':s[3]})
    return pd.DataFrame(out)
