from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd
import torch
import matplotlib.pyplot as plt
from .core import seed_all, make_dataset, ACTIONS
from .models import TransformerDecisionModel, ActorCritic, build_sequences, train_transformer, train_actor_critic
from .analysis import split_rows, baselines, model_eval, correlation, effective_rank, action_distribution, jacobian_report, pontryagin_report, trajectory_report


def run_seed(seed, programs, tepochs, acepisodes, out):
    seed_all(seed); rows=make_dataset(programs,seed,10); tr_rows,va_rows,te_rows=split_rows(rows,seed)
    Xtr,ytr=build_sequences(tr_rows); Xv,yv=build_sequences(va_rows)
    tr=TransformerDecisionModel(10); hist=train_transformer(tr,Xtr,ytr,tepochs,seed,device='cpu',val=(Xv,yv))
    ac=ActorCritic(10); ah=train_actor_critic(ac,acepisodes,6,.97,seed,'cpu')
    ev=model_eval(te_rows,tr,ac)
    ev['seed']=seed
    final_acc=hist[-1]['val_accuracy']; test_pred=ev['final_action'].notna().mean()
    return rows,tr,ac,ev,pd.DataFrame(hist),pd.DataFrame(ah),float(final_acc),test_pred


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['full','smoke'],default='full'); ap.add_argument('--programs',type=int,default=3000); ap.add_argument('--transformer-epochs',type=int,default=5); ap.add_argument('--ac-episodes',type=int,default=50); ap.add_argument('--out',default='outputs_v7'); args=ap.parse_args()
    if args.mode=='smoke':
        args.programs=min(args.programs,120); args.transformer_epochs=min(args.transformer_epochs,2); args.ac_episodes=min(args.ac_episodes,5)
    out=Path(args.out); (out/'figures').mkdir(parents=True,exist_ok=True)
    seeds=[42] if args.mode=='smoke' else [42,7,21,100,123]
    seed_records=[]; all_test=[]; primary=None
    for seed in seeds:
        rows,tr,ac,ev,th,ah,val_acc,_=run_seed(seed,args.programs,args.transformer_epochs,args.ac_episodes,out)
        seed_records.append({'seed':seed,'validation_accuracy':val_acc,'test_accuracy':ev.transformer_correct.mean(),'test_utility_delta':ev.utility_delta.mean(),'actor_critic_agreement':ev.actor_critic_agreement.mean(),'n_test':len(ev)})
        all_test.append(ev)
        if seed==42: primary=(rows,tr,ac,ev,th,ah)
    rows,tr,ac,ev,th,ah=primary
    pd.DataFrame(seed_records).to_csv(out/'multi_seed_results.csv',index=False)
    ev.to_csv(out/'test_predictions_seed42.csv',index=False); th.to_csv(out/'transformer_history_seed42.csv',index=False); ah.to_csv(out/'actor_critic_history_seed42.csv',index=False)
    base=baselines([r for r in rows if r['program_id'] in set(ev.program_id)])
    base.to_csv(out/'baseline_comparison_cases.csv',index=False)
    summary=base.groupby('method').utility_delta.mean().rename('mean_utility_delta').reset_index(); model_summary=pd.DataFrame([{'method':'I-GATE Transformer','mean_utility_delta':ev.utility_delta.mean(),'test_accuracy':ev.transformer_correct.mean(),'agreement':np.nan},{'method':'Actor-Critic (code-path)','mean_utility_delta':np.nan,'test_accuracy':np.nan,'agreement':ev.actor_critic_agreement.mean()}]); pd.concat([summary,model_summary],ignore_index=True).to_csv(out/'baseline_comparison.csv',index=False)
    corr=correlation(rows); corr.to_csv(out/'correlation_matrix.csv'); json.dump({'effective_rank':effective_rank(corr)},open(out/'effective_rank.json','w'),indent=2)
    action_distribution(ev).to_csv(out/'action_distribution.csv',index=False)
    jacobian_report(rows).to_csv(out/'jacobian_summary.csv',index=False); pontryagin_report(rows).to_csv(out/'pontryagin_summary.csv',index=False); trajectory_report(rows).to_csv(out/'trajectory_results.csv',index=False)
    # 5/8/10-state ablation using same benchmark size and compact training.
    ab=[]
    for ns in [5,8,10]:
        rns=make_dataset(min(args.programs,600),42,ns); trn,van,ten=split_rows(rns,42); Xt,yt=build_sequences(trn,ns); Xv,yv=build_sequences(van,ns); m=TransformerDecisionModel(ns); h=train_transformer(m,Xt,yt,args.transformer_epochs,42,'cpu',(Xv,yv)); ab.append({'state_dimension':ns,'validation_accuracy':h[-1]['val_accuracy']})
    pd.DataFrame(ab).to_csv(out/'state_ablation.csv',index=False)
    # Figures
    plt.figure(figsize=(8,5)); plt.plot(th.epoch,th.val_accuracy,marker='o'); plt.xlabel('Epoch'); plt.ylabel('Validation accuracy'); plt.title('Transformer validation performance'); plt.tight_layout(); plt.savefig(out/'figures/transformer_validation.png',dpi=250); plt.close()
    plt.figure(figsize=(8,5)); ev.final_action.value_counts().reindex(ACTIONS,fill_value=0).plot(kind='bar'); plt.ylabel('Test cases'); plt.title('State-dependent action distribution'); plt.tight_layout(); plt.savefig(out/'figures/action_distribution.png',dpi=250); plt.close()
    plt.figure(figsize=(8,5)); t=pd.read_csv(out/'trajectory_results.csv');
    for scenario,g in t.groupby('scenario'): plt.plot(g.time,g.risk,label=scenario)
    plt.xlabel('Time'); plt.ylabel('Risk'); plt.title('Dynamic risk trajectories'); plt.legend(); plt.tight_layout(); plt.savefig(out/'figures/risk_trajectory.png',dpi=250); plt.close()
    json.dump({'benchmark_programs':args.programs,'primary_seed':42,'robustness_seeds':seeds,'transformer_epochs':args.transformer_epochs,'actor_critic_episodes':args.ac_episodes,'device':'cpu','synthetic_only':True,'jacobian_solver':'finite_difference','pontryagin_solver':'discrete_time_forward_backward_sweep','sd_solver':'scipy.solve_ivp'},open(out/'run_metadata.json','w'),indent=2)
    print(json.dumps(seed_records,indent=2))

if __name__=='__main__': main()
