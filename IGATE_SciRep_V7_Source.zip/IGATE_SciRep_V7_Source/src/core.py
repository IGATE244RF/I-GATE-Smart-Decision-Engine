from __future__ import annotations
import random
from dataclasses import dataclass
import numpy as np

STATE_NAMES = ["cost","quality","risk","time","performance","maturity","sustainability","manufacturability","validation","confidence"]
ACTIONS = ["continue","redesign","additional_validation","supplier_mitigation","schedule_recovery","design_to_cost"]
GATES = ["Concept","System_Design","Design_Verification","Process_Validation","Launch_Readiness","Post_Launch"]
LOWER = {0,2,3}
WEIGHTS = np.array([.12,.14,.16,.12,.12,.10,.08,.06,.06,.04], dtype=np.float64)

@dataclass
class EnvConfig:
    n_states: int = 10
    nonlinear: bool = True
    delayed: bool = True
    feedback: bool = True
    horizon: int = 6

# Action effects are intentionally heterogeneous so the optimal action depends on state region.
ACTION_EFFECTS = np.array([
    [0,0,0,0,0,0,0,0,0,0],
    [.035,.090,-.100,.045,.050,.065,.015,.035,.085,.055],
    [.020,.045,-.135,.060,.015,.035,.005,.005,.150,.090],
    [.018,.025,-.080,.018,.005,.025,-.015,.080,.035,.045],
    [.045,-.010,.050,-.110,-.015,-.025,-.010,.025,-.020,-.010],
    [-.085,-.020,.025,.005,-.025,.005,-.015,.015,-.010,.005]
], dtype=np.float64)


def seed_all(seed: int):
    random.seed(seed); np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def generate_state(rng: np.random.Generator, n_states=10):
    m = rng.beta(3.0, 3.0)
    q = np.clip(.45 + .45*m + rng.normal(0,.12),0,1)
    p = np.clip(.35 + .55*m + rng.normal(0,.12),0,1)
    v = np.clip(.25 + .65*m + rng.normal(0,.12),0,1)
    s = np.clip(.35 + .45*m + rng.normal(0,.14),0,1)
    mf = np.clip(.30 + .55*m + rng.normal(0,.14),0,1)
    risk = np.clip(.75 - .45*m - .25*q + rng.normal(0,.12),0,1)
    time = np.clip(.35 + .35*(1-m) + .25*risk + rng.normal(0,.12),0,1)
    cost = np.clip(.40 + .28*risk + .18*(1-mf) + .12*(1-m) + rng.normal(0,.12),0,1)
    conf = np.clip(.25 + .65*v + rng.normal(0,.12),0,1)
    x = np.array([cost,q,risk,time,p,m,s,mf,v,conf],dtype=np.float64)
    if n_states == 5:
        return x[[0,1,2,3,5]]
    if n_states == 8:
        return x[[0,1,2,3,5,7,8,9]]
    return x


def utility(x):
    x=np.asarray(x,dtype=float)
    d=x.copy()
    for i in range(min(len(d),10)):
        if i in LOWER: d[i]=1-d[i]
    w = WEIGHTS[:len(d)]
    w = w/w.sum()
    # Nonlinear interactions create state-dependent optimal actions.
    u=float(np.dot(w,d))
    if len(d)>=10:
        u += .10*d[2]*d[8] + .08*d[0]*d[3] - .08*d[5]*(1-d[8])
    return u


def decision_score(x, action=None, gate=0):
    """Transparent synthetic state-dependent decision kernel.

    A normalized severity index maps the current state to six bounded decision
    regions. The thresholds are fixed benchmark constants and are not fitted to
    industrial outcomes.
    """
    x=np.asarray(x,dtype=float)
    if len(x)==5: x=np.array([x[0],x[1],x[2],x[3],0.5,x[4],0.5,0.5,0.5,0.5],dtype=float)
    elif len(x)==8: x=np.array([x[0],x[1],x[2],x[3],0.5,x[4],0.5,x[5],x[6],x[7]],dtype=float)
    cost,q,risk,time,performance,maturity,sustainability,mf,validation,conf=x[:10]
    severity=(0.22*cost+0.18*time+0.20*risk+0.15*(1-maturity)+0.15*(1-q)+0.10*(1-mf))
    thresholds=np.array([0.37,0.42,0.47,0.52,0.59])
    idx=int(np.digitize(severity,thresholds))
    # A small gate prior can move only an adjacent region; state severity remains dominant.
    if gate>=5 and idx<5 and severity>0.55: idx=min(5,idx+1)
    scores=np.full(len(ACTIONS),-1.0,dtype=float)
    scores[idx]=1.0-abs(severity-(thresholds[idx-1] if idx>0 else 0.32))*0.1
    # Keep neighbouring actions feasible but lower-ranked.
    if idx>0: scores[idx-1]=0.25
    if idx<5: scores[idx+1]=0.25
    return scores if action is None else float(scores[int(action)])


def transition(x, action, gate=0, disturbance=None, dt=1.0):
    x=np.asarray(x,dtype=float).copy(); n=len(x)
    full=np.zeros(10); idx = [0,1,2,3,5] if n==5 else ([0,1,2,3,5,7,8,9] if n==8 else list(range(10)))
    full[idx]=x
    f=full.copy()
    maturity=f[5]; validation=f[8]; risk=f[2]; quality=f[1]; schedule=f[3]
    # endogenous feedback terms
    f[5] += dt*(.025*(1-maturity) + .035*validation - .030*risk)
    f[8] += dt*(.030*maturity + .025*quality - .020*risk)
    f[2] += dt*(.020*(1-quality) - .040*maturity - .025*validation)
    f[3] += dt*(.025*(1-maturity) + .020*risk - .015*validation)
    f[9] += dt*.030*validation
    f[1] += dt*.020*maturity - dt*.015*risk
    f[0] += dt*.018*risk + dt*.012*(1-f[7])
    f[4] += dt*.020*maturity - dt*.015*risk
    f[6] += dt*.010*maturity
    f[7] += dt*.018*f[4] - dt*.010*f[0]
    if action >= 0:
        e=ACTION_EFFECTS[action]
        # nonlinear state-action interactions
        f += e
        if action==1: f[2] -= .045*(1-f[8]); f[5] += .025*(1-f[5])
        if action==2: f[8] += .050*(1-f[8]); f[2] -= .030*f[8]
        if action==3: f[2] -= .030*(1-f[7]); f[7] += .035*(1-f[7])
        if action==4: f[3] -= .045*(1-f[5]); f[5] -= .010
        if action==5: f[0] -= .050*(1-f[7]); f[1] -= .010
    if disturbance is not None:
        f += np.asarray(disturbance)
    f=np.clip(f,0,1)
    return f[idx]


def disturbance(rng, n=10, severity=1.0):
    return rng.normal(0, np.array([.015,.015,.020,.020,.012,.012,.012,.012,.018,.012])*severity, size=n)


def make_dataset(n=3000, seed=42, n_states=10):
    rng=np.random.default_rng(seed); rows=[]
    for i in range(n):
        x=generate_state(rng,n_states)
        row={"program_id":f"P{i+1:05d}","gate":int(rng.integers(0,6))}
        for j,v in enumerate(x): row[STATE_NAMES[[0,1,2,3,5][j] if n_states==5 else ([0,1,2,3,5,7,8,9][j] if n_states==8 else j)]]=float(v)
        rows.append(row)
    return rows


def row_to_state(row,n_states=10):
    names=[STATE_NAMES[i] for i in ([0,1,2,3,5] if n_states==5 else ([0,1,2,3,5,7,8,9] if n_states==8 else range(10)))]
    return np.array([row[k] for k in names],dtype=float)


def rollout(x, actions, gate=0, horizon=None):
    horizon=horizon or len(actions); states=[np.asarray(x,dtype=float).copy()]; cur=states[0]
    for t in range(horizon):
        cur=transition(cur,int(actions[t]),gate=min(gate+t,5)); states.append(cur.copy())
    return np.asarray(states)
