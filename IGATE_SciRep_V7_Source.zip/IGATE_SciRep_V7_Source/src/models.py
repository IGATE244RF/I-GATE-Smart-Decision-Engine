from __future__ import annotations
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
from .core import transition, utility, decision_score, generate_state, ACTIONS

class TemporalTransformer(nn.Module):
    def __init__(self,state_dim=10,d_model=64,heads=4,layers=2):
        super().__init__(); self.proj=nn.Linear(state_dim,d_model)
        enc=nn.TransformerEncoderLayer(d_model,heads,dropout=.1,batch_first=True,activation='gelu')
        self.encoder=nn.TransformerEncoder(enc,layers); self.norm=nn.LayerNorm(d_model)
    def forward(self,x): return self.norm(self.encoder(self.proj(x))[:,-1,:])

class TransformerDecisionModel(nn.Module):
    def __init__(self,state_dim=10):
        super().__init__(); self.encoder=TemporalTransformer(state_dim)
        self.head=nn.Sequential(nn.Linear(64,64),nn.GELU(),nn.Linear(64,len(ACTIONS)))
    def forward(self,x): return self.head(self.encoder(x))

class ActorCritic(nn.Module):
    def __init__(self,state_dim=10):
        super().__init__(); self.encoder=TemporalTransformer(state_dim)
        self.actor=nn.Sequential(nn.Linear(64,64),nn.Tanh(),nn.Linear(64,len(ACTIONS)))
        self.critic=nn.Sequential(nn.Linear(64,64),nn.Tanh(),nn.Linear(64,1))
    def forward(self,x):
        z=self.encoder(x); return self.actor(z),self.critic(z).squeeze(-1)

def build_sequences(rows,n_states=10,seq_len=6):
    X=[]; y=[]
    for row in rows:
        names = [k for k in row if k not in ('program_id','gate')]
        x=np.array([row[k] for k in names],dtype=np.float32); gate=int(row['gate']); seq=[x]
        for k in range(seq_len-1): seq.append(transition(seq[-1],0,gate=min(gate+k,5)))
        scores=decision_score(x,gate=gate)
        X.append(seq); y.append(int(np.argmax(scores)))
    return np.asarray(X,np.float32),np.asarray(y,np.int64)

def train_transformer(model,X,y,epochs=5,seed=42,device='cpu',val=None):
    torch.manual_seed(seed); model.to(device); opt=optim.AdamW(model.parameters(),lr=1e-3); lossfn=nn.CrossEntropyLoss(); hist=[]
    ds=torch.utils.data.TensorDataset(torch.tensor(X,dtype=torch.float32),torch.tensor(y,dtype=torch.long))
    gen=torch.Generator(); gen.manual_seed(seed)
    dl=torch.utils.data.DataLoader(ds,batch_size=128,shuffle=True,generator=gen)
    xv,yv=(None,None) if val is None else (torch.tensor(val[0],dtype=torch.float32,device=device),torch.tensor(val[1],dtype=torch.long,device=device))
    for ep in range(epochs):
        model.train(); losses=[]
        for xb,yb in dl:
            xb=xb.to(device); yb=yb.to(device); logits=model(xb); loss=lossfn(logits,yb); opt.zero_grad(); loss.backward(); opt.step(); losses.append(float(loss.detach()))
        model.eval()
        with torch.no_grad():
            train_logits=model(torch.tensor(X,dtype=torch.float32,device=device)); train_acc=float((train_logits.argmax(1)==torch.tensor(y,device=device)).float().mean())
            val_acc=float((model(xv).argmax(1)==yv).float().mean()) if xv is not None else np.nan
        hist.append({'epoch':ep+1,'loss':float(np.mean(losses)),'train_accuracy':train_acc,'val_accuracy':val_acc})
    return hist


def train_actor_critic(model,episodes=50,horizon=6,gamma=.97,seed=42,device='cpu'):
    torch.manual_seed(seed); model.to(device); opt=optim.Adam(model.parameters(),lr=2e-4); hist=[]
    for ep in range(episodes):
        rng=np.random.default_rng(seed+ep); state=generate_state(rng,len(model.encoder.proj.in_features and range(10)) if False else 10)
        # Match the model's state dimension when required.
        sd=model.encoder.proj.in_features
        if sd!=10: state=state[[0,1,2,3,5] if sd==5 else [0,1,2,3,5,7,8,9]]
        seq=[state.copy()]; logs=[]; vals=[]; rewards=[]
        for t in range(horizon):
            arr=np.asarray(seq[-6:],np.float32)
            if len(arr)<6: arr=np.vstack([np.repeat(arr[:1],6-len(arr),axis=0),arr])
            logits,value=model(torch.tensor(arr,device=device).unsqueeze(0)); dist=Categorical(logits=logits); act=dist.sample(); a=int(act.item())
            ns=transition(state,a,gate=t); reward=utility(ns)-utility(state)
            logs.append(dist.log_prob(act).squeeze()); vals.append(value.squeeze()); rewards.append(torch.tensor(reward,device=device)); state=ns; seq.append(state.copy())
        G=torch.tensor(0.,device=device); returns=[]
        for r in reversed(rewards): G=r+gamma*G; returns.insert(0,G)
        R=torch.stack(returns); V=torch.stack(vals); L=torch.stack(logs); adv=R-V.detach(); actor=-(L*adv).mean(); critic=.5*(R-V).pow(2).mean(); loss=actor+critic
        opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
        hist.append({'episode':ep+1,'reward':float(torch.stack(rewards).sum()),'loss':float(loss.detach())})
    return hist

def predict(model,seq,actor=False,device='cpu'):
    model.eval()
    with torch.no_grad():
        inp=torch.tensor(seq,dtype=torch.float32,device=device).unsqueeze(0)
        logits,*rest=model(inp) if actor else (model(inp),)
        p=torch.softmax(logits,dim=-1).squeeze().cpu().numpy(); val=float(rest[0].item()) if rest else np.nan
    return int(np.argmax(p)),p,val
