from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar
from .core import transition, utility, ACTIONS, rollout


def jacobian_fd(f, x, eps=1e-5):
    x=np.asarray(x,dtype=float); y0=np.asarray(f(x),dtype=float)
    J=np.zeros((len(y0),len(x)))
    for j in range(len(x)):
        h=eps*max(1.0,abs(x[j])); xp=x.copy(); xm=x.copy(); xp[j]+=h; xm[j]-=h
        J[:,j]=(np.asarray(f(xp))-np.asarray(f(xm)))/(2*h)
    return J


def transition_jacobian(x, action, gate=0, eps=1e-5):
    return jacobian_fd(lambda z: transition(z,action,gate=gate), np.asarray(x,dtype=float), eps)


def hamiltonian(x, lam, action, gate=0, rho=0.01):
    # Discrete-time Hamiltonian: H(x,u,lambda)= -U(x,u) + lambda^T f(x,u) + rho||u||^2
    xn=transition(x,action,gate=gate)
    return -utility(xn) + float(np.dot(lam,xn)) + rho*(action**2)


def pontryagin_solver(x0, horizon=6, gate=0, iterations=30, gamma=0.97):
    """Finite-horizon discrete-time Pontryagin forward-backward sweep.

    State equation: x_{t+1}=f(x_t,u_t)
    Cost: sum_t gamma^t [-U(x_{t+1}) + rho u_t^2]
    Costate recursion approximated by finite-difference Jacobian.
    Control is selected from the finite action set by minimizing the local Hamiltonian.
    """
    x0=np.asarray(x0,dtype=float); n=len(x0); H=int(horizon)
    actions=np.zeros(H,dtype=int)
    for _ in range(iterations):
        xs=[x0.copy()]
        for t in range(H): xs.append(transition(xs[-1],int(actions[t]),gate=min(gate+t,5)))
        lambdas=[np.zeros(n) for _ in range(H+1)]
        for t in range(H-1,-1,-1):
            # terminal costate from negative utility gradient
            xnext=xs[t+1]
            gradU=jacobian_fd(lambda z: np.array([utility(z)]),xnext).reshape(-1)
            J=transition_jacobian(xs[t],int(actions[t]),gate=min(gate+t,5))
            lambdas[t]= -gradU + gamma*(J.T@lambdas[t+1])
        new_actions=[]
        for t in range(H):
            vals=[hamiltonian(xs[t],lambdas[t+1],a,gate=min(gate+t,5)) for a in range(len(ACTIONS))]
            new_actions.append(int(np.argmin(vals)))
        new_actions=np.array(new_actions,dtype=int)
        if np.array_equal(new_actions,actions): break
        actions=new_actions
    states=rollout(x0,actions,gate,H)
    utility_gain=float(utility(states[-1])-utility(states[0]))
    hs=[hamiltonian(states[t],lambdas[t+1] if t+1<len(lambdas) else np.zeros(n),int(actions[t]),gate=min(gate+t,5)) for t in range(H)]
    return {"actions":actions,"action_names":[ACTIONS[a] for a in actions],"states":states,"costates":np.asarray(lambdas),"hamiltonians":np.asarray(hs),"terminal_utility_gain":utility_gain,"iterations":_+1}


def sd_simulate(x0, action_sequence, horizon=12, gate=0):
    """Continuous-time SD-compatible simulation using the same nonlinear transition field.

    The vector field is obtained as f(x,u)-x and integrated with solve_ivp. This is a
    computational benchmark representation, not an empirically calibrated industrial SD model.
    """
    x0=np.asarray(x0,dtype=float); n=len(x0); actions=list(action_sequence)
    def rhs(t,x):
        k=min(int(np.floor(t)),len(actions)-1)
        target=transition(x,int(actions[k]),gate=min(gate+k,5))
        return target-x
    sol=solve_ivp(rhs,(0,float(horizon)),x0,t_eval=np.linspace(0,horizon,horizon*10+1),rtol=1e-6,atol=1e-8)
    return sol.t,sol.y.T
